const config = {
    network: {
        baseEndPointUrl: 'http://localhost:51406'
    },
    apiEndpoints: {
        compareString: '/api/StringCompare/CompareString'
    }
};

export default config;