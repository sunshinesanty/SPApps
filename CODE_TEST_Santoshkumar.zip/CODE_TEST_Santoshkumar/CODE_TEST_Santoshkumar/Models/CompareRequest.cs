﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CODE_TEST_Santoshkumar.Models
{
    public class CompareRequest
    {
        public string SourceString { get; set; }
        public string SubString { get; set; }
    }
}